It is hard to spawn a cube within .25m of another cube, so I dragged the cube to another cube to test if their colors change to white within .25m. 
